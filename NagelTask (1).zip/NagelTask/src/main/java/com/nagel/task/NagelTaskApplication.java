package com.nagel.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NagelTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(NagelTaskApplication.class, args);
	}

}
